package comp2402a2;

import java.util.ArrayList;
import java.util.LinkedList;

/**
 * This class implements the MyStack interface.
 * @author sharp
 *
 * @param <T> the type of objects stored in the MyStack
 */
public class MyFastStack<T> implements MyStack<T> {
	ArrayList<T> MyStack = new ArrayList<>();
	
	public MyFastStack() {
    // TODO: Your code goes here


	}

	public int size() {
    // TODO: Your code goes here
		return MyStack.size();
	}

	
	public void push(T x) {
		// TODO: Your code goes here

		if ((MyStack.size() == 0) || !(x.equals(MyStack.get(MyStack.size() - 1)))) {
			MyStack.add(x);
		} else {

			MyStack.remove(MyStack.size() - 1);
		}
	}
	
	public T pop() {
    // TODO: Your code goes here

			if( MyStack.size() == 0 ){
				return null;
			}
			return MyStack.remove(MyStack.size()-1);
	}
	@Override
	public String toString() {

		return MyStack.toString();
	}
}
