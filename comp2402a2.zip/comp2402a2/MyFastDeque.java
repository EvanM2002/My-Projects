package comp2402a2;

import java.util.ArrayDeque;
import java.util.ArrayList;

/**
 * This class implements the MyDeque interface.
 * @author sharp
 *
 * @param <T> the type of objects stored in the MyDeque
 */
public class MyFastDeque<T> implements MyDeque<T> {
	ArrayDeque<T> list = new ArrayDeque<>();;


	public MyFastDeque() {
    // TODO: Your code goes here

	}

	public int size() {
    // TODO: Your code goes here
		return list.size();

	}

	public void addFirst(T x) {
		// TODO: Your code goes here

		if ((list.size() == 0) || !(x.equals(list.getFirst()))) {
			list.addFirst(x);

		}
		else {
			list.removeFirst();
		}



	}



	public void addLast(T x) {
		// TODO: Your code goes here


		if ((list.size() == 0) || !(x.equals(list.getLast()))) {
			list.addLast(x);

		}
		else {
			list.removeLast();
		}
	}
	public T removeFirst () {
			// TODO: Your code goes here
		if (list.size() == 0) {
			return null;
		}
		return list.removeFirst();



		}
		public T removeLast () {
				// TODO: Your code goes here

			if (list.size() == 0) {
				return null;
			}

			return list.removeLast();



	}

	@Override
	public String toString() {
		return list.toString();
	}

}
