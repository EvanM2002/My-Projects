
package comp2402a5;
/*
 * author: Alexa Sharp
 */


public class MySubsetMeld implements SubsetMeld {
    int[] id;
    int[] storingArray;
    int root;
    int n;
    int k;


    public MySubsetMeld(int n) {
        id = new int[n];
        storingArray = new int[n];
        int root = 0;
        for (int i = 0; i < n; i++) {
            id[i] = i;
        }
        this.n = n;
        this.k = n;

    }


    public boolean same(int x, int y) {
        if (rootValue(x) == rootValue(y)){
            return true;
        }
        else{
            return false;
        }
    }


    public void meld(int x, int y) {
        if (same(x,y)) {
            return;
        }
        int rootMeld1 = rootValue(x);
        int rootMeld2 = rootValue(y);
        if (storingArray[rootMeld2] > storingArray[rootMeld1]) {
            storingArray[rootMeld2] += storingArray[rootMeld1];
            id[rootMeld1] = rootMeld2;
            storingArray[rootMeld1] = 0;
        } else {
            storingArray[rootMeld1] += storingArray[rootMeld2];
            id[rootMeld2] = rootMeld1;
            storingArray[rootMeld2] = 0;
        }
        k--;
    }


    public int size() { return n; }


    public int numSubsets() { return k;}

    public String toString() {
        // This is a basic toString.
        StringBuilder sb = new StringBuilder();
        for( int i=0; i < n; i++ ) {
            sb = sb.append(i + ": " + id[i] + "\n");
        }
        return sb.toString();
    }

    public int rootValue(int x) {
        int nextValue=0;
        root = x;
        while (root != id[root]){
            root = id[root];
        }
        while (x != root) {
            nextValue = id[x];
            id[x] = root;
            x = nextValue;
        }

        return root;
    }
}
