package comp2402a1;

import java.util.AbstractList;
import java.util.Collection;

/**
 * This class implements the MyList interface as a single array a.
 * Elements are stored at positions a[0],...,a[size()-1].
 * Doubling/halving is used to resize the array a when necessary.
 * @author morin
 * @author sharp
 *
 * @param <T> the type of objects stored in the List
 */
public class MyArrayStack<T> implements MyList<T> {

	/**
	 * The array used to store elements
	 */
	T[] a;

	/**
	 * The number of elements stored
	 */
	int n;

	/**
	 * Resize the internal array
	 */
	protected void resize() {
		@SuppressWarnings("unchecked")
		T[] b = (T[])new Object[Math.max(n*2, 1)];
		for (int i = 0; i < n; i++) {
			b[i] = a[i];
		}
		a = b;
	}

	/**
	 * Constructor
	 */
	@SuppressWarnings("unchecked")
	public MyArrayStack() {
		a = (T[])new Object[1];
		n = 0;
	}

	/**
	 * Constructor
	 *
	 * @param cap
	 */
	@SuppressWarnings("unchecked")
	public MyArrayStack(int cap) {
		a = (T[])new Object[cap];
		n = 0;
	}

	public int size() {
		return n;
	}

	public T get(int i) {
		if (i < 0 || i > n - 1) throw new IndexOutOfBoundsException();
		return a[i];
	}

	public T set(int i, T x) {
		if (i < 0 || i > n - 1) throw new IndexOutOfBoundsException();
		T y = a[i];
		a[i] = x;
		return y;
	}

	public void add(int i, T x) {
		if (i < 0 || i > n) throw new IndexOutOfBoundsException();
		if (n + 1 > a.length) resize();
		for (int j = n; j > i; j--)
			a[j] = a[j-1];
		a[i] = x;
		n++;
	}

	public T remove(int i) {
		if (i < 0 || i > n - 1) throw new IndexOutOfBoundsException();
		T x = a[i];
		for (int j = i; j < n-1; j++)
			a[j] = a[j+1];
		n--;
		if (a.length >= 3*n) resize();
		return x;
	}

	public String toString() {
		// TODO: Override this with more useful behaviour for debugging.
		String s = "[";
		for (int i = 0; i < n; i++) {
			s += a[i];
			if (i != n-1) {
				s += ", ";
			}
		}
		s += "]";
		return s;
	}

	public MyList<T> shuffle(MyList<T> other) {
		// TODO: Return the shuffle of this and other.
		MyList<T> list = new MyArrayStack<T>(n + other.size());
		for (int i = 0; i < n || i < other.size(); i++) {
			if (i < n) {
				list.add(list.size(), a[i]);
			}
			if (i < other.size()) {
				list.add(list.size(), other.get(i));
			}
		}
		return list;

	}

	public MyList<MyList<T>> countOff(int n) {
		// TODO: Return a list of n lists, made by counting off
		MyList<MyList<T>> l = new MyArrayStack<MyList<T>>();

		if(n>0){

			for(int i = 0; i<n; i++){
				l.add(l.size(),new MyArrayStack());
			}

			for(int i=0;i<this.size();i++){
				l.get(i%n).add(l.get(i%n).size(),this.get(i));
			}
		}
		return l;
	}

	public void reverse() {
		for (int i = 0; i < n/2; i++) {
			T temp = a[i];
			a[i] = a[n-1-i];
			a[n -1-i] = temp;
		}
	}
}